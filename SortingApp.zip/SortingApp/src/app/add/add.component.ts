import { Component, OnInit } from '@angular/core';
import { EmpserviceService } from '../empservice.service';
import { Emp } from '../emp';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'],
})
export class AddComponent implements OnInit {
  empObj: Emp = new Emp();
  private form: FormGroup;

  constructor(private fb: FormBuilder, private empservice: EmpserviceService) { }

  ngOnInit() {
    this.form = this.fb.group({
      id: ["", Validators.required],
      name: ["", Validators.required],
      salary: ["", Validators.required],
      department: ["", Validators.required],
    });
  }
  addEmp() {
    //this.empservice.addEmp(empObj)
    //this.empObj = new Emp()
    if (this.form.valid) {
      let data=this.form.value;
      var emp={ 
        id: data.id, 
        empName:data.name,  
        empSal:data.salary,
        empDep:data.department
      };
      console.log(emp);
      this.empservice.addEmp(emp);
    }
    else {
      alert("Invalid form");
    }

  }

}
