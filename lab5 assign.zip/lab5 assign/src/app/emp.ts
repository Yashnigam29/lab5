export class Emp {
    id:Number;
    empName:string;
    empSal:Number;
    empDepart:string;
}
