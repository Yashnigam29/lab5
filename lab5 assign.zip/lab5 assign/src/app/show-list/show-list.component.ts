import { Component, OnInit,  } from '@angular/core';
import { Emp } from '../emp';
import { EmpService} from '../emp.service'

@Component({
  selector: 'app-show-list',
  templateUrl: './show-list.component.html',
  styleUrls: ['./show-list.component.css'],
  providers:[EmpService]
})
export class ShowListComponent implements OnInit {

   emps:Emp[]=[
      {id:1001,empName:'Rahul',empSal:4500,empDepart:'cs'},
      {id:1002,empName:'yash',empSal:65500,empDepart:'cse'},
      {id:1003,empName:'pri',empSal:10500,empDepart:'it'},
      {id:1004,empName:'aman',empSal:20500,empDepart:'civil'}
   ];
  // emp:Emp=new Emp();
  constructor(private empservice:EmpService) { }

  ngOnInit() {
  }
    
  remove(eid:Number):void{
     this.emps=this.emps.filter(x=> x.id!=eid);
    console.log(JSON.stringify(this.emps));

}
}
