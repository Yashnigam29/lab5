import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';

@Component({
  selector: 'app-showsearch',
  templateUrl: './showsearch.component.html',
// template:'{{emps}}<app-search (MessageEvent)=receivemessage($event)></app-search>',
  styleUrls: ['./showsearch.component.css']
})
export class ShowsearchComponent implements OnInit {

  emps:Emp[]=[
    {id:1001,empName:'Rahul',empSal:4500,empDepart:'cs'},
    {id:1002,empName:'yash',empSal:65500,empDepart:'cse'},
    {id:1003,empName:'pri',empSal:10500,empDepart:'it'},
    {id:1004,empName:'aman',empSal:20500,empDepart:'civil'}

 ];
  constructor() { }

  ngOnInit() {
  }
// receivemessage($event):void{
// this.emps=$event
// }
}
