import { Injectable } from '@angular/core';
import { Emp } from './emp';

@Injectable()
export class EmpService {

  emp5:Emp[]=[];
  
  constructor() { }
  addemp(e:Emp):EmpService{
      console.log(JSON.stringify(e));
     this.emp5.push(e);
    //  console.log(JSON.stringify(this.emp5))
    return this;
  }
  getAll():Emp[]{
    return this.emp5;
  }
  // remove(eid:Number):EmpService{
  //   this.emp5=this.emp5.filter(x=> x.id!=eid)
  //   return this;
  // }

}
