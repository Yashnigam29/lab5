import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmpService} from '../emp.service'

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'],
  providers:[EmpService]
})
export class AddComponent implements OnInit {

  emps:Emp[]=[];
  emp:Emp=new Emp();
  constructor(private empservice:EmpService) { }

  ngOnInit() {
  }
  addemp():void{
    this.empservice.addemp(this.emp);
    this.emps=this.empservice.getAll();
    console.log(JSON.stringify(this.emp))
    console.log(JSON.stringify(this.emps))
     this.emp=new Emp();
  }

}
