import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { EmpComponent } from './emp/emp.component';
import {approutingmodule,routingComponent} from './approutingmodule';
import {FormsModule} from '@angular/forms';
import { SearchPipe }  from './filter';
// import { SearchComponent } from './search/search.component';
// import { ShowsearchComponent } from './showsearch/showsearch.component';
// import { AddComponent } from './add/add.component';
// import { ShowListComponent } from './show-list/show-list.component';

@NgModule({
  declarations: [
    AppComponent,
    EmpComponent,
    routingComponent,
    SearchPipe
  ],
  imports: [
    BrowserModule,approutingmodule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
