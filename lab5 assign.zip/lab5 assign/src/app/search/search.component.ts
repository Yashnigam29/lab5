import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { Emp } from '../emp';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
// template:'<div><button (click)="sendmessage()"></button></div>'
  // styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  search:string='';
  emps:Emp[]=[
    {id:1001,empName:'Rahul',empSal:4500,empDepart:'cs'},
    {id:1002,empName:'yash',empSal:65500,empDepart:'cse'},
    {id:1003,empName:'pri',empSal:10500,empDepart:'it'},
    {id:1004,empName:'aman',empSal:20500,empDepart:'civil'}
 ];
// @Output() MessageEvent=new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
// sendmessage():void{
//   this.MessageEvent.emit(this.emps);
// }
}
