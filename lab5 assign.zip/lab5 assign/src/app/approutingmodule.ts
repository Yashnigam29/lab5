import { NgModule } from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import { AddComponent } from './add/add.component';
import { ShowListComponent } from './show-list/show-list.component';
import { SearchComponent } from './search/search.component';
import { ShowsearchComponent } from './showsearch/showsearch.component';
const routes: Routes=[
    {path:'add', component:AddComponent},
    {path:'show',component:ShowListComponent},
    {path:'search',component:SearchComponent},
    {path:'showsearch',component:ShowsearchComponent}
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
export class approutingmodule{}
export const routingComponent=[AddComponent,ShowListComponent,SearchComponent,ShowsearchComponent]