import {  Pipe, PipeTransform }      from '@angular/core';
// import { Employee } from "./app.employee";
// import{Emp} from './emp'
@Pipe({
  name: 'searchPipe'
  
})
export class SearchPipe implements PipeTransform {
    transform(emp:any, search:any): any {
           if(search==undefined) return emp;
           return emp.filter(function(employes:any){
               console.log(employes);
               return employes.empName.toLowerCase().includes(search.toLowerCase());
           })
        }
  
  }
